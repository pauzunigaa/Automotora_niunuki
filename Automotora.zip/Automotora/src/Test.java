
/**
 *
 * @author paulinazunigaalarcon
 */
public class Test {
    public static void main(String[] args) {
        
        Automovil automovil1 = new Automovil("77777777", 22, 30_000, 40_000);
        Cliente cliente1 = new Cliente("5555555", "YOUNG MIKO", "Lesli@soifleta.cl",569999 ,'P', automovil1);
        
        cliente1.montoaPagar();
        cliente1.setTipoCliente('N');
        System.out.println(" Nuevo tipo cliente : "+cliente1.getTipoCliente());
        System.out.println(" Descuento asociado " + cliente1.montoDescuento(cliente1.getAutomovil().getValorPesocl()));
    }
}
