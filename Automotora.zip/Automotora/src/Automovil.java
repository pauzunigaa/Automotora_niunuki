
/**
 *
 * @author paulinazunigaalarcon
 */
public class Automovil {

    private String numeroChasis;
    private double kmsxLts, valorPesocl, cargoMantencion; // se puede ocupar double, float

    public Automovil() {
    }

    public Automovil(String numeroChasis, double kmsxLts, double valorPesocl, double cargoMantencion) {
        this.setNumeroChasis(numeroChasis);
        this.kmsxLts = kmsxLts;
        this.valorPesocl = valorPesocl;
        this.cargoMantencion = cargoMantencion;
    }

    public String getNumeroChasis() {
        return numeroChasis;
    }

    public double getKmsxLts() {
        return kmsxLts;
    }

    public double getValorPesocl() {
        return valorPesocl;
    }

    public double getCargoMantencion() {
        return cargoMantencion;
    }

    public void setNumeroChasis(String numeroChasis) {
        if (numeroChasis.length() == 8) {
            this.numeroChasis = numeroChasis;

        } else {
            System.out.println("El chasis debe tener 8 digitos.");
        }
    }

    public void setKmsxLts(double kmsxLts) {
        this.kmsxLts = kmsxLts;
    }

    public void setValorPesocl(double valorPesocl) {
        if (valorPesocl > 0 && valorPesocl < 5100000) {
            this.valorPesocl = valorPesocl;

        } else {
            System.out.println(" El valor debe estar entre 0 y 5.100.000.");
        }
    }

    public void setCargoMantencion(double cargoMantencion) {
        this.cargoMantencion = cargoMantencion;
    }

    @Override
    public String toString() {
        return "Automovil{" + "numeroChasis=" + numeroChasis + ", kmsxLts=" + kmsxLts + ", valorPesocl=" + valorPesocl + ", cargoMantencion=" + cargoMantencion + '}';
    }

}
