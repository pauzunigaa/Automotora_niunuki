
/**
 *
 * @author paulinazunigaalarcon
 */
public class Cliente {

    private String rut, nombreCompleto, correo;
    private int telefono;
    private char tipoCliente; // tipo de boolean como mostrar como por ejemplo 'M' o 'F'
    private Automovil automovil;

    public Cliente() {
    }

    public Cliente(String rut, String nombreCompleto, String correo, int telefono, char tipoCliente, Automovil automovil) {
        this.rut = rut;
        this.nombreCompleto = nombreCompleto;
        this.correo = correo;
        this.telefono = telefono;
        this.setTipoCliente(tipoCliente);
        this.automovil = automovil;
    }

    public String getRut() {
        return rut;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public String getCorreo() {
        return correo;
    }

    public int getTelefono() {
        return telefono;
    }

    public char getTipoCliente() {
        return tipoCliente;
    }

    public Automovil getAutomovil() {
        return automovil;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public void setTipoCliente(char tipoCliente) { // validacion tipo de cliente
        if (tipoCliente == 'P' || tipoCliente == 'N') {
            this.tipoCliente = tipoCliente;

        } else {
            System.out.println(" Ingrese 'P' o 'N' segun corresponda ");
        }
    }

    public void setAutomovil(Automovil automovil) {
        this.automovil = automovil;
    }

    @Override
    public String toString() {
        return "Cliente{" + "rut=" + rut + ", nombreCompleto=" + nombreCompleto + ", correo=" + correo + ", telefono=" + telefono + ", tipoCliente=" + tipoCliente + ", automovil=" + automovil + '}';
    }

    public void mostrarDatos() { // creando el metodo
        System.out.println(" LISTA DE CLIENTES ");
        System.out.println("____________________");
        System.out.println(this.getNombreCompleto());
        System.out.println(this.getTelefono());

        // validamos que el cliente fuera NORMAL
        if (this.getTipoCliente() == 'P') {
            System.out.println(" Eres cliente PREFERENCIAL");

        } else {
            System.out.println("Eres cliente NORMAL");
        }
        System.out.println("____________________");
    }

    public void validarAutocliente(String chasisIngresado) { // creamos un parametro nuevo
        if (this.getAutomovil().getNumeroChasis().equalsIgnoreCase(chasisIngresado)) {
            System.out.println("Este chasis corresponde a su dueño");

        } else {
            System.out.println("No corresponde");
        }
    }

    public double montoDescuento(double montoTotal) {
        double descuento = 0;
        if (this.getTipoCliente() == 'P') {
            descuento = 0.10 * montoTotal;
        }
        return descuento;
    }
    
    public void montoaPagar(){
    double valorBruto = this.getAutomovil().getValorPesocl();
    double descuento = this.montoDescuento(valorBruto);
    double total = valorBruto - descuento;
    double iva = total *0.19;
    
    
        System.out.println("TOTAL A PAGAR:");
        System.out.println("");
        System.out.println("Valor Bruto: " + valorBruto);
        System.out.println("Descuento: " + descuento);
        System.out.println("Total: " + total);
        System.out.println("IVA : " + iva);
        System.out.println("A PAGAR " + (iva + total));
    }
    
    public void montoMantencion (){
        double montoMensual = 1500000;
        double descuento = 0;
        if (this.getTipoCliente() == 'P') {
            descuento = montoMensual * 0.10;
            
            
        }else{
        descuento = montoMensual * 0.05;
        }
        System.out.println(" El descuento será de : " + descuento);
    }
    
}

